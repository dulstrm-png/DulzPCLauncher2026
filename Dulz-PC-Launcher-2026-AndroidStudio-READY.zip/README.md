# Dulz-PC-Launcher-2026

Launcher Android Native Kotlin untuk **Dulz | STRM**.

## Spesifikasi
- Android Native, Kotlin, tanpa WebView.
- Min Android 8.0 / API 26.
- Compile/Target SDK 35.
- Login lokal dan ganti akun.
- Logout kembali ke halaman login.
- Akun dapat dibuat dari halaman login.
- Launcher modern dark/glassmorphism dengan aksen merah.
- Menu aplikasi, pencarian, pengaturan, tanggal/jam, dan shortcut aplikasi.
- Bisa dijadikan launcher HOME Android melalui intent HOME.

## Akun awal
- Username: `Dulz`
- Password: `2026`

Akun disimpan lokal di SharedPreferences. Ini adalah login lokal/offline, bukan sistem autentikasi server.

## Build
Buka folder ini di Android Studio, tunggu Gradle Sync selesai, lalu pilih:
`Build > Build APK(s)`

Atau dari terminal:
`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan
`gradle-wrapper.jar` disertakan sebagai bootstrap wrapper kecil yang mengambil Gradle 8.7 sesuai
`gradle-wrapper.properties` ketika diperlukan. Android Studio tetap dapat menggunakan Gradle wrapper
untuk proses Sync/Build.
