package com.dulz.pc

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private val prefs by lazy { getSharedPreferences("dulz_launcher", Context.MODE_PRIVATE) }
    private var overlay: View? = null
    private var currentUser: String? = null

    private val apps = listOf(
        "🎮  Game Store",
        "🌐  Chrome",
        "📁  File Explorer",
        "⚙️  Pengaturan",
        "🔎  Pencarian"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        ensureDefaultAccount()

        currentUser = prefs.getString("session_user", null)
        if (currentUser.isNullOrBlank()) {
            showLogin()
        } else {
            showDesktop()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (overlay != null) {
                    closeOverlay()
                } else if (currentUser.isNullOrBlank()) {
                    finish()
                } else {
                    showDesktop()
                }
            }
        })
    }

    private fun ensureDefaultAccount() {
        if (!prefs.getBoolean("default_created", false)) {
            prefs.edit()
                .putBoolean("default_created", true)
                .putString("account_Dulz", "2026")
                .apply()
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun text(
        value: String,
        size: Float = 15f,
        color: Int = Color.WHITE
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply {
            text = value
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun editText(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            hintTextColor = Color.rgb(130, 130, 130)
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(Color.rgb(28, 28, 28))
        }

    private fun base(): FrameLayout {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(5, 5, 5))
        setContentView(root)
        return root
    }

    private fun showLogin() {
        closeOverlay()
        currentUser = null
        base()

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(60), dp(28), dp(30))
        }

        val brand = text("DULZ | STRM", 28f, Color.rgb(229, 9, 20))
        brand.gravity = Gravity.CENTER
        box.addView(brand, LinearLayout.LayoutParams(-1, -2))

        val title = text("Dulz PC Launcher 2026", 21f)
        title.gravity = Gravity.CENTER
        box.addView(title)

        val subtitle = text("Masuk untuk membuka launcher", 14f, Color.rgb(165, 165, 165))
        subtitle.gravity = Gravity.CENTER
        box.addView(subtitle)

        val username = editText("Username")
        val password = editText("Password")
        password.inputType =
            android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        box.addView(username, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(30)
        })
        box.addView(password, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(12)
        })

        val login = button("MASUK") {
            val user = username.text.toString().trim()
            val pass = password.text.toString()

            if (user.isEmpty() || pass.isEmpty()) {
                toast("Username dan password wajib diisi.")
                return@button
            }

            val saved = prefs.getString("account_$user", null)
            if (saved != null && saved == pass) {
                prefs.edit().putString("session_user", user).apply()
                currentUser = user
                showDesktop()
            } else {
                toast("Username atau password salah.")
            }
        }

        box.addView(login, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(20)
        })

        box.addView(
            button("BUAT AKUN") { showCreateAccount() },
            LinearLayout.LayoutParams(-1, dp(52)).apply {
                topMargin = dp(8)
            }
        )

        val info = text(
            "Akun awal: Dulz / 2026\nLogin tersimpan secara lokal di perangkat.",
            12f,
            Color.rgb(125, 125, 125)
        )
        info.gravity = Gravity.CENTER
        box.addView(info, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(25)
        })

        scroll.addView(box)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showCreateAccount() {
        closeOverlay()

        val p = panel()
        p.addView(text("Buat Akun", 24f))
        p.addView(text("Akun baru disimpan di perangkat ini.", 13f, Color.LTGRAY))

        val username = editText("Username baru")
        val password = editText("Password baru")
        val confirm = editText("Ulangi password")
        password.inputType =
            android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        confirm.inputType =
            android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

        p.addView(username, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(20) })
        p.addView(password, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
        p.addView(confirm, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })

        p.addView(button("SIMPAN AKUN") {
            val user = username.text.toString().trim()
            val pass = password.text.toString()
            val pass2 = confirm.text.toString()

            if (user.length < 3 || pass.length < 4) {
                toast("Username minimal 3 karakter dan password minimal 4 karakter.")
                return@button
            }
            if (pass != pass2) {
                toast("Konfirmasi password tidak sama.")
                return@button
            }
            if (prefs.contains("account_$user")) {
                toast("Username sudah digunakan.")
                return@button
            }

            prefs.edit().putString("account_$user", pass).apply()
            toast("Akun berhasil dibuat.")
            showLogin()
        }, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(18)
        })

        p.addView(button("← Kembali") { showLogin() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6) })

        showOverlay(p)
    }

    private fun showDesktop() {
        closeOverlay()
        base()

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(82))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        titleBox.addView(text("Dulz | STRM", 24f, Color.rgb(229, 9, 20)))
        titleBox.addView(text("PC Launcher 2026", 13f, Color.rgb(165, 165, 165)))
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        header.addView(button("⋮") { showQuickMenu() },
            LinearLayout.LayoutParams(dp(52), dp(52)))
        content.addView(header)

        val welcome = text(
            "Selamat datang, ${currentUser ?: "Pengguna"}",
            16f,
            Color.WHITE
        )
        content.addView(welcome, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(20)
        })

        val date = text(
            SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date()),
            13f,
            Color.rgb(145, 145, 145)
        )
        content.addView(date)

        val grid = GridLayout(this).apply {
            columnCount = if (resources.configuration.screenWidthDp < 500) 2 else 3
            useDefaultMargins = false
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(18)
        })

        val iconLabels = listOf(
            "🎮\nGame Store",
            "🌐\nChrome",
            "📁\nFile Explorer",
            "⚙️\nPengaturan",
            "🔎\nPencarian",
            "🏠\nHome"
        )

        iconLabels.forEach { label ->
            val b = button(label) {
                when (label.substringAfter("\n")) {
                    "Game Store" -> toast("Game Store siap digunakan.")
                    "Chrome" -> openChrome()
                    "File Explorer" -> openExplorer()
                    "Pengaturan" -> showSettings()
                    "Pencarian" -> showSearch()
                    "Home" -> showDesktop()
                }
            }
            b.gravity = Gravity.CENTER
            b.textSize = 14f
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(112)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            grid.addView(b, params)
        }

        val taskbar = LinearLayout(this).apply {
            setBackgroundColor(Color.rgb(16, 16, 16))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
        }
        root.addView(taskbar, FrameLayout.LayoutParams(-1, dp(62), Gravity.BOTTOM))

        taskbar.addView(button("☰  Menu") { showStartMenu() },
            LinearLayout.LayoutParams(dp(105), -1))

        taskbar.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))

        val clock = text("", 12f, Color.WHITE)
        clock.gravity = Gravity.CENTER
        taskbar.addView(clock, LinearLayout.LayoutParams(dp(165), -1))

        updateClock(clock)
    }

    private fun updateClock(clock: TextView) {
        clock.text = SimpleDateFormat("HH:mm\nEEE, dd MMM", Locale("id", "ID")).format(Date())
        clock.postDelayed({ if (!isFinishing) updateClock(clock) }, 1000)
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(28), dp(20), dp(20))
        setBackgroundColor(Color.rgb(12, 12, 12))
    }

    private fun showStartMenu() {
        closeOverlay()
        val p = panel()

        p.addView(text("Dulz PC", 25f, Color.rgb(229, 9, 20)))
        p.addView(text("Aplikasi & menu", 13f, Color.LTGRAY))

        val search = editText("Cari aplikasi")
        p.addView(search, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(16)
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        p.addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(10)
        })

        fun fill(query: String) {
            list.removeAllViews()
            apps.filter { it.contains(query, true) }.forEach { app ->
                list.addView(button(app) {
                    closeOverlay()
                    when (app.substringAfter("  ")) {
                        "Game Store" -> toast("Game Store siap digunakan.")
                        "Chrome" -> openChrome()
                        "File Explorer" -> openExplorer()
                        "Pengaturan" -> showSettings()
                        "Pencarian" -> showSearch()
                    }
                }, LinearLayout.LayoutParams(-1, dp(50)))
            }
            if (list.childCount == 0) {
                list.addView(text("Aplikasi tidak ditemukan.", 13f, Color.LTGRAY))
            }
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                fill(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        fill("")

        p.addView(button("⚙ Pengaturan") { showSettings() },
            LinearLayout.LayoutParams(-1, dp(50)))
        p.addView(button("⇄ Ganti Akun") { logout() },
            LinearLayout.LayoutParams(-1, dp(50)))
        p.addView(button("✕ Keluar") { finish() },
            LinearLayout.LayoutParams(-1, dp(50)))

        showOverlay(p)
    }

    private fun showQuickMenu() {
        val items = arrayOf("Pengaturan", "Ganti Akun", "Keluar")
        android.app.AlertDialog.Builder(this)
            .setTitle("Menu Dulz PC")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showSettings()
                    1 -> logout()
                    2 -> finish()
                }
            }
            .show()
    }

    private fun showSearch() {
        closeOverlay()
        val p = panel()
        p.addView(text("Pencarian", 24f))

        val input = editText("Ketik pencarian...")
        val result = text("", 14f, Color.LTGRAY)
        p.addView(input, LinearLayout.LayoutParams(-1, dp(52)).apply {
            topMargin = dp(16)
        })
        p.addView(result, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(15)
        })

        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString().orEmpty()
                result.text = if (q.isBlank()) "Ketik nama aplikasi atau fitur."
                else apps.filter { it.contains(q, true) }.joinToString("\n")
                    .ifBlank { "Tidak ada hasil." }
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })

        p.addView(button("← Kembali") { showDesktop() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(25) })

        showOverlay(p)
    }

    private fun showSettings() {
        closeOverlay()
        val p = panel()

        p.addView(text("Pengaturan", 24f, Color.rgb(229, 9, 20)))
        p.addView(text("Dulz PC Launcher 2026", 13f, Color.LTGRAY))

        p.addView(button("👤 Akun: ${currentUser ?: "-"}") {
            toast("Akun aktif: ${currentUser ?: "-"}")
        }, LinearLayout.LayoutParams(-1, dp(50)).apply {
            topMargin = dp(20)
        })

        p.addView(button("⇄ Ganti Akun") { logout() },
            LinearLayout.LayoutParams(-1, dp(50)))

        p.addView(button("🏠 Jadikan Launcher Default") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (_: Exception) {
                toast("Pengaturan launcher tidak tersedia.")
            }
        }, LinearLayout.LayoutParams(-1, dp(50)))

        p.addView(button("ℹ Tentang") {
            android.app.AlertDialog.Builder(this)
                .setTitle("Dulz PC Launcher 2026")
                .setMessage(
                    "Versi 2026.1\n\nNative Kotlin Android.\n" +
                    "Dibuat untuk Dulz | STRM."
                )
                .setPositiveButton("OK", null)
                .show()
        }, LinearLayout.LayoutParams(-1, dp(50)))

        p.addView(button("← Kembali") { showDesktop() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(18) })

        showOverlay(p)
    }

    private fun logout() {
        closeOverlay()
        prefs.edit().remove("session_user").apply()
        currentUser = null
        showLogin()
    }

    private fun openChrome() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        try {
            startActivity(intent)
        } catch (_: Exception) {
            toast("Browser tidak tersedia.")
        }
    }

    private fun openExplorer() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            toast("File Explorer tidak tersedia.")
        }
    }

    private fun showOverlay(content: View) {
        val frame = FrameLayout(this).apply {
            setBackgroundColor(0xDD000000.toInt())
        }
        frame.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, FrameLayout.LayoutParams(-1, -1))
        overlay = frame

        frame.alpha = 0f
        frame.animate().alpha(1f).setDuration(180).start()
    }

    private fun closeOverlay() {
        overlay?.let { root.removeView(it) }
        overlay = null
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
